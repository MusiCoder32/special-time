<template>
<view>查看readme.md.js中使用说明</view>
</template>

<script>
export default {
  name: "index.vue"
}
</script>

<style scoped>

</style>