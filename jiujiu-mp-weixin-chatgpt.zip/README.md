### 注意:国内无法直接使用chat,体验小程序中使用了aws服务器。源码只有chatgpt的使用方法，无法使你直接访问chatgpt,，服务器问题自行解决

注意事项：
1.全局搜索'wx4a5ed7f7fc719f98(小程序appid)'与'd84b16d5dae43c848d7260e4d6e22159(小程序secret)'，替换成自己的
2.仅小程序与h5原生支持流式写入,app需嵌入webview
3.代码主要逻辑在vue页面中，故将其后缀改成了.js，购买源码后，修改后缀名即可
4.index.vue.js中是采用了nodejs转发方式，index-old.vue.js中是直接访问chatgpt接口方式；app.js与index.js是node服务器转发相关代码；

### 描描下方二维码，在个人中心-->工具箱-->时光丫，体验chatgpt
<img src="//img-cdn-aliyun.dcloud.net.cn/stream/plugin_screens/28607500-b410-11ed-a2d3-391270c19e93_3.jpg?1680538113" width="35%">
