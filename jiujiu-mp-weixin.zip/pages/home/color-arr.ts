// export default ['#CDECFE', '#CFFAF5', '#FFE7EE', '#F5EFD0', '#D7DCFC']
export default ['#CDECFE', '#EFEBD7', '#D7F6F3', '#DBDFFB', '#FBE8EF']
