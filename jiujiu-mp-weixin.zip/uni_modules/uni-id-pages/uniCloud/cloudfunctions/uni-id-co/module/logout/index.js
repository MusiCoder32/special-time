module.exports = {
  logout: require('./logout')
}
