module.exports = {
  createCaptcha: require('./create-captcha'),
  refreshCaptcha: require('./refresh-captcha'),
  sendSmsCode: require('./send-sms-code'),
  sendEmailLink: require('./send-email-link'),
  sendEmailCode: require('./send-email-code')
}
